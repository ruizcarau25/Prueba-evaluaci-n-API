import { Component, inject, OnInit, signal } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Vehicle } from '../../interfaces/swapi-responses';
import { VehicleService } from '../../services/vehicle-service';
import { VehicleDetailModalComponent } from '../../components/vehicle-detail-modal/vehicle-detail-modal';
import { VehicleItemComponent } from '../../components/vehicle-item-component/vehicle-item-component';

@Component({
  selector: 'app-vehicles-list-page',
  imports: [VehicleItemComponent],
  templateUrl: './vehicles-list-page.html',
  styleUrl: './vehicles-list-page.css',
})
export class VehiclesListPage implements OnInit {
  private readonly vehicleService = inject(VehicleService);
  private readonly modalService = inject(NgbModal);

  readonly vehicles = signal<Vehicle[]>([]);

  ngOnInit(): void {
    this.vehicleService
      .getVehicles()
      .subscribe((response) => this.vehicles.set(response.results));
  }

  openVehicle(id: string): void {
    this.vehicleService
      .getVehicle(id)
      .subscribe((vehicle) => {
        const modalRef = this.modalService.open(VehicleDetailModalComponent);
        modalRef.componentInstance.vehicle = vehicle;
      });
  }
}
