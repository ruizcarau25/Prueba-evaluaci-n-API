import { Component, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Film } from '../../interfaces/swapi-responses';
import { VehicleService } from '../../services/vehicle-service';

@Component({
  selector: 'app-film-item-page',
  imports: [RouterLink],
  templateUrl: './film-item-page.html',
  styleUrl: './film-item-page.css',
})
export class FilmItemPage implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly vehicleService = inject(VehicleService);

  readonly film = signal<Film | null>(null);

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.vehicleService.getFilm(id).subscribe((film) => this.film.set(film));
    }
  }
}
