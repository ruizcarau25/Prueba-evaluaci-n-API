import { Component, inject, OnInit, signal } from '@angular/core';
import { Film } from '../../interfaces/swapi-responses';
import { VehicleService } from '../../services/vehicle-service';
import { FilmItemComponent } from '../../components/film-item-component/film-item-component';

@Component({
  selector: 'app-film-list-page',
  imports: [FilmItemComponent],
  templateUrl: './films-list-page.html',
  styleUrl: './films-list-page.css',
})
export class FilmListPage implements OnInit {
  private readonly vehicleService = inject(VehicleService);

  readonly films = signal<Film[]>([]);

  ngOnInit(): void {
    this.vehicleService
      .getFilms()
      .subscribe((response) => this.films.set(response.results));
  }
}
