import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Film } from '../../interfaces/swapi-responses';
import { getSwapiId } from '../../utils/swapi';

@Component({
  selector: 'app-film-item-component',
  imports: [RouterLink],
  templateUrl: './film-item-component.html',
  styleUrl: './film-item-component.css',
})
export class FilmItemComponent {
  readonly film = input.required<Film>();

  get id(): string {
    return getSwapiId(this.film().url);
  }
}
