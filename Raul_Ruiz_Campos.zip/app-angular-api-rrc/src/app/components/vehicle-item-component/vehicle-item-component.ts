import { Component, input, output } from '@angular/core';
import { Vehicle } from '../../interfaces/swapi-responses';
import { getSwapiId } from '../../utils/swapi';

@Component({
  selector: 'app-vehicle-item-component',
  templateUrl: './vehicle-item-component.html',
  styleUrl: './vehicle-item-component.css',
})
export class VehicleItemComponent {
  readonly vehicle = input.required<Vehicle>();
  readonly vehicleSelected = output<string>();

  get id(): string {
    return getSwapiId(this.vehicle().url);
  }
}
