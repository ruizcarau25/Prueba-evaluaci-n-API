import { Component, inject, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Vehicle } from '../../interfaces/swapi-responses';

@Component({
  selector: 'app-vehicle-detail-modal',
  templateUrl: './vehicle-detail-modal.html',
  styleUrl: './vehicle-detail-modal.css',
})
export class VehicleDetailModalComponent {
  @Input({ required: true }) vehicle!: Vehicle;

  readonly activeModal = inject(NgbActiveModal);
}
