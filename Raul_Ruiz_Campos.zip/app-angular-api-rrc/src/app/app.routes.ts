import { Routes } from '@angular/router';
import { FilmItemPage } from './pages/film-item-page/film-item-page';
import { FilmListPage } from './pages/films-list-page/films-list-page';
import { VehiclesListPage } from './pages/vehicles-list-page/vehicles-list-page';

export const routes: Routes = [
	{ path: 'vehicles', component: VehiclesListPage },
	{ path: 'films/:id', component: FilmItemPage },
	{ path: 'films', component: FilmListPage },
	{ path: '', pathMatch: 'full', redirectTo: 'vehicles' },
	{ path: '**', redirectTo: 'vehicles' },
];
