import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Film, SwapiListResponse, Vehicle } from '../interfaces/swapi-responses';

@Injectable({ providedIn: 'root' })
export class VehicleService {
	private readonly http = inject(HttpClient);
	private readonly baseUrl = 'https://swapi.dev/api';

	getVehicles(): Observable<SwapiListResponse<Vehicle>> {
		return this.http.get<SwapiListResponse<Vehicle>>(`${this.baseUrl}/vehicles/`);
	}

	getVehicle(id: string): Observable<Vehicle> {
		return this.http.get<Vehicle>(`${this.baseUrl}/vehicles/${id}/`);
	}

	getFilms(): Observable<SwapiListResponse<Film>> {
		return this.http.get<SwapiListResponse<Film>>(`${this.baseUrl}/films/`);
	}

	getFilm(id: string): Observable<Film> {
		return this.http.get<Film>(`${this.baseUrl}/films/${id}/`);
	}
}
