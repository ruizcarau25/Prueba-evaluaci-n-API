export function getSwapiId(resourceUrl: string): string {
  const segments = new URL(resourceUrl).pathname.split('/').filter(Boolean);
  return segments.at(-1) ?? '';
}
