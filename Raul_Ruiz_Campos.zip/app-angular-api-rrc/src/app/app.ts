import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MenuToolbar } from './components/menu-toolbar/menu-toolbar';

@Component({
  imports: [MenuToolbar, RouterOutlet],
  selector: 'app-root',
  styleUrl: './app-shell.css',
  templateUrl: './app-shell.html',
})
export class App {}
